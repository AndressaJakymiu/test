/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: analves- <analves-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 17:57:19 by analves-          #+#    #+#             */
/*   Updated: 2025/07/20 18:44:34 by analves-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>

static void	free_all(char **res, int j)
{
	while (j-- > 0)
		free(res[j]);
	free(res);
}

static int	save_word(char **res, const char *s, int start, int len, int j)
{
	res[j] = ft_substr(s, start, len);
	if (!res[j])
	{
		free_all(res, j);
		return (0);
	}
	return (1);
}

void	ft_do_split(char **res, const char *s, char c)
{
	int	i;
	int	j;
	int	start;
	int	len;

	i = 0;
	j = 0;
	start = -1;
	while (s[i])
	{
		if (s[i] != c && start < 0)
			start = i;
		if ((s[i] == c || (s[i + 1] == '\0')) && start >= 0)
		{
			len = i - start;
			if (s[i] != c && s[i + 1] == '\0')
				len++;
			if (!save_word(res, s, start, len, j++))
				return ;
			start = -1;
		}
		i++;
	}
	res[j] = NULL;
}

char	**ft_split(char const *s, char c)
{
	char	**res;

	if (!s)
		return (NULL);
	res = (char **)malloc(sizeof(char *) * (ft_strlen(s) + 1));
	if (!res)
		return (NULL);
	ft_do_split(res, s, c);
	return (res);
}
