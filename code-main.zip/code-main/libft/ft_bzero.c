/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: analves- <analves-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/14 15:52:49 by analves-          #+#    #+#             */
/*   Updated: 2025/07/14 16:10:06 by analves-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
// #include <stdio.h>

void	ft_bzero( void *s, size_t n)
{
	ft_memset(s, 0, n);
}

// int main(void)
// {
// 	char str[9] = "abcdefgh";
// 	int numV = 0;
// 	printf("before :  %s\n", str);
// 	numV = ft_strlen(str);
// 	ft_bzero(str, numV);
// 	printf("after : %s", str);
// }